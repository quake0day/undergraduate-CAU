import os,sys,filecmp,shutil
file_new = '2h'    #define new_score_file_name
file_old = '3h'        #define old_score_file_name
do_script = 'dogetscore'    #define the scriptname you wanna execute
do_getscore = 'savescore'  #define the scriptname which can get new score
f1h = os.path.join(sys.path[0],file_new) 	#get new_score_file PATH
f2h = os.path.join(sys.path[0],file_old) 	#get old_score_file PATH
getscore = os.path.join(sys.path[0],do_getscore) 	#get script PATH
str1 = os.popen(getscore).read()
re = filecmp.cmp(f1h,f2h)
if re == 0:	#if 25h is different with 26h
	filename = os.path.join(sys.path[0],do_script) 	#get script PATH
	str = os.popen(filename).read()  # run the script
shutil.copyfile(f1h, f2h) #copy new_score for further compare
