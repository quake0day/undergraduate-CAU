<?
$URL='http://202.205.88.60:8888/loginAction.do';
$post_data['zjh'] = "XXXX"; // student id
$post_data['mm'] = "XXXXX"; // password
$referrer="http://202.205.88.60:8888/logout.do";
$session_id = "XXXXXXX"; // your session_id
// parsing the given URL
$URL_Info=parse_url($URL);
// Building referrer
if($referrer=="") // if not given use this script as referrer
$referrer=$_SERVER["SCRIPT_URI"];
// making string from $data
foreach($post_data as $key=>$value)
$values[]="$key=".urlencode($value);
$data_string=implode("&",$values);
// Find out which port is needed - if not given use standard (=80)
if(!isset($URL_Info["port"]))
$URL_Info["port"]=8888;
// building POST-request:
$request.="POST ".$URL_Info["path"]." HTTP/1.1\n";
$request.="Host: ".$URL_Info["host"]."\n";
$request.="Referer: $referrer\n";
$request.="Content-type: application/x-www-form-urlencoded\n";
$request.="Content-length: ".strlen($data_string)."\n";
$request.="Connection: Keep-Alive\n";
$request.="Cache-Control: no-cache\n";
$request.="Cookie: JSESSIONID=".$session_id."\n";
$request.="\n";
$request.=$data_string."\n";
$fp = fsockopen($URL_Info["host"],$URL_Info["port"]);
fputs($fp, $request);
sleep(1);	//waiting for CAU jwc service give session
set_time_limit(0);
$HTTP_Server="202.205.88.60:8888/bxqcjcxAction.do";
$HTTP_URL="/";
$ch = curl_init();
curl_setopt ($ch,CURLOPT_URL,"http://".$HTTP_Server);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch,CURLOPT_USERAGENT,"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 1.1.4322; .NET CLR 2.0.50727)");
curl_setopt($ch,CURLOPT_COOKIE,"JSESSIONID=".$session_id);
$res = curl_exec($ch);
curl_close ($ch);
print_r($res);
fclose($fp);
?>


