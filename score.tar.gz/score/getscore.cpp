#include <stdio.h>
#include "libfetion/libfetion.h"

void Printf_AllGroup_Info();
void Printf_AllAccount_Info();

int main(int argc, char** argv)
{
	//init the libfetion frist
	if (!fx_init())
	{
		fprintf(stderr, "init the app fail \n");
		return 1;
	}

	//login the fetion
	if (!fs_login(argv[1], argv[2]))
	{
		fprintf(stderr, "login fail the error code is  \n" );
		return 1;
	}

	//here will will show how to get the fetion's group information..
	//Printf_AllGroup_Info();

	//here will will show how to get the fetion's group information..
	//Printf_AllAccount_Info();

	//if you want to send a shormessage to somebody, you can call fs_send_sms..
	//fs_send_sms(uid, msg);

	if (! fs_send_sms(YOUR_FETION_NUMBER, argv[3]) ) {
        fprintf(stderr, "send to others error\n");
    }

    if (! fs_send_sms_to_self(argv[3]) ) {
        fprintf(stderr, "send to myself error\n");
    }

	//login out ....
	fx_loginout();

	//destroy the libfetion
	fx_terminate();
}

void Printf_AllGroup_Info()
{
	Fetion_Group *group = NULL;
	DList *tmp = (DList *)fx_get_group();

	while(tmp)
	{
		group = (Fetion_Group *) tmp->data;

		if(group) {
			fprintf(stderr, "the group id is %d, group name is %s \n",
					group->id, group->name);
		}

		tmp = d_list_next(tmp);
	}

}

void Printf_AllAccount_Info()
{
	Fetion_Account *account = NULL;
	DList *tmp_account = (DList *)fx_get_account();
	while(tmp_account)
	{
		 account = (Fetion_Account *)tmp_account->data;

		 if(account)
		 {
			 int group_no = fx_get_account_group_id(account);
			 char *showname = fx_get_account_show_name(account, true);
			 fprintf(stderr, "the account id is %d, is belong to group %d, it showname is %s \n",
			 				account->id, group_no, showname?showname:" ");
			if (showname)
				delete showname;
			}
			tmp_account = d_list_next(tmp_account);
	}
}
